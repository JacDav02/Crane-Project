#!/usr/bin/env python3

from ev3dev2.motor import LargeMotor, OUTPUT_A, OUTPUT_B, SpeedPercent, MoveTank

m1 = LargeMotor(OUTPUT_A)
m2 = LargeMotor(OUTPUT_B)
tank = MoveTank(OUTPUT_A, OUTPUT_B)

tank.on_for_rotations(SpeedPercent(-50), SpeedPercent(-50), 4)
print("MB: Target Reached.")