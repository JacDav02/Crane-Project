import serial
import paramiko
import time

print("Connecting to Ev3")
try:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
except:
    print("Connection Failed")

print("Connecting to Micro:bit")
try:
    ser = serial.Serial('/dev/ttyACM0', 115200, timeout = 0.1)
except:
    ser = serial.Serial('/dev/ttyACM1', 115200, timeout = 0.1)
client.connect("10.0.0.70",22,"robot","maker")
serin = ""

while True:
    serin = ser.readline()
    time.sleep(1)
    print(serin)
    if "auto" in str(serin):
       stdin, stdout, stderr = client.exec_command('cd EV3')
       print(stderr.read().decode('ascii').strip("\n"))
       stdin, stdout, stderr = client.exec_command("""sudo ./Auto""")
       print(stderr.read().decode('ascii').strip("\n"))
       print(stdout.read().decode('ascii').strip("\n"))
       #write to serial v1
       ser.write((str(stdout.read()) + '\n').encode('UTF-8'))
       #write to serial v2
       #ser.write(stdout.read()).encode('UTF-8')
       #ser.write(('\n').encode(UTF-8))
       #if 1 doesnt work try 2, if neither work perish
       client.close()