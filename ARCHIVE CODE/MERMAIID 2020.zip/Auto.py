#!/usr/bin/env python3
import time
import sys
from ev3dev2.motor import Motor, LargeMotor, OUTPUT_A, OUTPUT_B, OUTPUT_C, SpeedPercent, MoveTank
from ev3dev2.sensor import INPUT_1, INPUT_2, INPUT_3, INPUT_4
from ev3dev2.sensor.lego import UltrasonicSensor
m1 = LargeMotor(OUTPUT_A)
m2 = LargeMotor(OUTPUT_B)
m3 = Motor(OUTPUT_C)
tank = MoveTank(OUTPUT_A, OUTPUT_B)
usforward = UltrasonicSensor('in1')
usleft = UltrasonicSensor('in2')
usright = UltrasonicSensor('in3')

done = False
lastDir = ""
lastDir2 = ""
wallBuffer = 6
eDist = 2.5
loops = 0
freeLoops = 0
distTraveled = 0
distTarget = 25
distforward = 0
distleft = 0
distright = 0
distlist = []
distclosest = 0
dirclosest = ""
relaysTotal = 4

m1.ramp_up_sp = 250
m1.ramp_down_sp = 250
m2.ramp_up_sp = 250
m2.ramp_down_sp = 250
m3.ramp_up_sp = 0
m3.ramp_down_sp = 0


def update():
    global distforward
    global distleft
    global distright
    global dirclosest
    global distclosest
    distforward = usforward.distance_inches
    distleft = usleft.distance_inches
    distright = usright.distance_inches
    distlist = [distforward, distleft, distright]
    distclosest = min(distlist)
    if distforward < distleft and distforward < distright:
        dirclosest = "f"
    if distright < distleft and distright < distforward:
        dirclosest = "r"
    if distleft < distforward and distleft < distright:
        dirclosest = "l"
    print(str(distclosest) + 'c')
    print(dirclosest)
    print(str(distforward) + 'f')
    print(str(distleft) + 'l')
    print(str(distright) + 'r')


def moveForward():
    global distTraveled
    print("movingforward")
    tank.on_for_rotations(SpeedPercent(100), SpeedPercent(100), 0.35)
    distTraveled += 1


def turnLeft():
    print("movingleft")
    tank.on_for_rotations(SpeedPercent(-100), SpeedPercent(100), 0.35)


def turnRight():
    print("movingright")
    tank.on_for_rotations(SpeedPercent(100), SpeedPercent(-100), 0.35)


def moveBack():
    print("movingback")
    global distTraveled
    tank.on_for_rotations(SpeedPercent(-100), SpeedPercent(-100), 1)
    distTraveled + - 1


def dropRelay():
    global relaysTotal
    global distTraveled
    if distTraveled > distTarget:
        distTraveled = 0
        if relaysTotal > 0:
            m3.on_for_rotations(SpeedPercent(100), 0.5)
            relaysTotal -= 1
            print(relaysTotal)
        if relaysTotal == 0:
            print("Out of relays!")
    print("bruh2")


def navigate():
    global lastDir
    global lastDir2
    global distforward
    global distleft
    global distright
    global loops
    global freeLoops
    print(distclosest)
    while distclosest > wallBuffer:
        moveForward()
        update()
    if dirclosest == "f" and distclosest <= wallBuffer:
        if distforward <= eDist:
            moveBack()
            update()

        elif distright <= wallBuffer and distleft <= wallBuffer:
            moveBack()
            update()
        elif distleft >= distright:
            turnLeft()
            update()
        elif distleft <= distright:
            turnRight()
            update()
        else:
            update()
    if dirclosest == "l" and distclosest <= wallBuffer:
        if distleft <= eDist:
            turnRight()
            update()
        elif distforward <= wallBuffer and distright <= wallBuffer:
            moveBack()
            update()
        elif distright >= distforward:
            turnRight()
            update()
        elif distright <= distforward:
            moveForward()
            update()
        else:
            update()
    if dirclosest == "r" and distclosest <= wallBuffer:
        if distright <= eDist:
            turnLeft()
            update()
        elif distforward <= wallBuffer and distleft <= wallBuffer:
            moveBack()
            update()
        elif distleft >= distforward:
            moveForward()
            update()
        elif distleft <= distforward:
            turnLeft()
            update()
        else:
            update()
    if distforward > 100 and distright > 100 and distleft > 100:
        freeLoops += 1
        print("Free Loops: " + str(freeLoops))
        if freeLoops > 5:
            print("Path Cleared")
    else:
        freeLoops = 0
    loops += 1
    print()
    print("Loop #" + str(loops))
    update()
        # if distforward < 0.25*wallBuffer:
        #     moveBack()
        #     update()
        # elif distleft > distright:
        #     turnRight()
        #     update()
        # elif distleft < distright:
        #     turnLeft()
        #     update()
        # else:
        #     update()


moveForward()
while done == False:
    navigate()
    dropRelay()
    print("bruh")
