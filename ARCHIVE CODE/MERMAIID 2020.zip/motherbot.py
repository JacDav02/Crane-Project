import serial
import paramiko
import time

print("Connecting to Ev3")
try: 
     client = paramiko.SSHClient() 
     client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
except:
    print("Connection Failed")

print("Connecting to Micro:bit")
try:
    ser = serial.Serial('/dev/ttyACM0', 115200, timeout = 0.1)
except:
    ser = serial.Serial('/dev/ttyACM1', 115200, timeout = 0.1)
client.connect("10.0.0.65",22,"robot","maker")
serin = ""
userinput = ""
finished = False

while True:
    userinput = input("Submit Command: ")
    print(userinput)
    if "move" in userinput:
       stdin, stdout, stderr = client.exec_command("""cd /home/robot/MotherBot""")
       print(stderr.read().decode('ascii').strip("\n"))
       print(stdout.read().decode('ascii').strip("\n"))
       stdin, stdout, stderr = client.exec_command("""sudo python3 /home/robot/MotherBot/MotherBot.py""")
       print(stderr.read().decode('ascii').strip("\n"))
       print(stdout.read().decode('ascii').strip("\n"))
    if "auto" in userinput:
       ser.write((userinput + '\n').encode())
       print("Sent: " + "\"" + userinput + "\"")
    if "read" in userinput:
        serin = ser.readline()
        print(serin)
